package kr.ac.tukorea.ge.spgp2025.a2dg.framework.interfaces;

public interface IRecyclable {
    public void onRecycle();
}
